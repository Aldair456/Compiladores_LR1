import json
import os
import logging
from datetime import datetime
from typing import Dict, Any, List, Set, Tuple
from collections import defaultdict
from src.utils.funciones_auxiales import (
    extraer_symbols_from_grammar,
    calcular_first_table
)
from src.utils.funciones_auxiliares_table import (
    construir_conjuntos_lr1,
    LR1Item,
    calcular_follow_table,
    generar_tabla_lr1
)

# Configurar logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def expandir_producciones_con_pipe(productions):
    """
    Expande las producciones que contienen el símbolo | (pipe) en múltiples producciones separadas.
    
    Args:
        productions: Lista de strings con las producciones
    
    Returns:
        list: Lista de producciones expandidas sin pipes
    """
    expanded = []
    
    for production in productions:
        # Normalizar espacios alrededor de '->'
        if '->' in production:
            left, right_part = production.split('->', 1)
        else:
            left, right_part = production.split(' -> ', 1)
        left = left.strip()
        right_part = right_part.strip()

        # Separar alternativas por '|', sin depender de espacios
        alternatives = [alt.strip() for alt in right_part.split('|')]

        # Si no hay '|', alternatives tendrá un solo elemento
        for alt in alternatives:
            expanded.append(f"{left} -> {alt}")
    
    return expanded


def calcular_first_cadena(simbolos, first_table):
    """
    Calcula FIRST(β) para una cadena de símbolos β.
    
    Args:
        simbolos: Lista de símbolos [X1, X2, ..., Xn]
        first_table: Tabla FIRST calculada
    
    Returns:
        set: FIRST(β)
    """
    if not simbolos:
        return {'ε'}
    
    result = set()
    for i, simbolo in enumerate(simbolos):
        if simbolo in first_table:
            first_set = set(first_table[simbolo])
            result.update(first_set - {'ε'})
            if 'ε' not in first_set:
                break
        else:
            # Es un terminal
            result.add(simbolo)
            break
    else:
        # Si todos pueden ser ε, agregar ε
        result.add('ε')
    
    return result


def calcular_closure_lr1(items, productions, first_table):
    """
    Calcula el closure LR(1) de un conjunto de elementos siguiendo el algoritmo correcto.
    
    Mientras exista un ítem [A → α • B β, a] en I con B no terminal:
    - Para cada producción B → γ
    - Para cada b ∈ FIRST(βa)
    - Agrega [B → • γ, b] a I si no está.
    
    Args:
        items: Conjunto de elementos LR(1)
        productions: Lista de producciones
        first_table: Tabla FIRST calculada
    
    Returns:
        set: Closure LR(1) del conjunto
    """
    closure = set(items)
    changed = True
    
    while changed:
        changed = False
        
        for item in list(closure):
            symbol_after_dot = item.get_symbol_after_dot()
            
            if symbol_after_dot and symbol_after_dot not in ['$', 'ε']:
                # Buscar producciones que empiecen con este símbolo
                for production in productions:
                    left, right = production.split(' -> ')
                    left = left.strip()
                    
                    if left == symbol_after_dot:
                        # Calcular FIRST(βa) donde β son los símbolos después del punto
                        right_symbols = right.split()
                        beta_alpha = []
                        
                        # Obtener símbolos después del punto en el item original
                        item_left, item_right = item.production.split(' -> ')
                        item_right_symbols = item_right.split()
                        
                        # Símbolos después del punto (β)
                        if item.dot_position + 1 < len(item_right_symbols):
                            beta = item_right_symbols[item.dot_position + 1:]
                            beta_alpha.extend(beta)
                        
                        # Agregar lookahead del item original (α)
                        beta_alpha.append(item.lookahead)
                        
                        # Calcular FIRST(βa)
                        lookaheads = calcular_first_cadena(beta_alpha, first_table)
                        
                        for lookahead in lookaheads:
                            if lookahead != 'ε':  # No agregar ε como lookahead
                                new_item = LR1Item(production, 0, lookahead)
                                if new_item not in closure:
                                    closure.add(new_item)
                                    changed = True
    
    return closure


def calcular_goto_lr1(items, symbol, productions, first_table):
    """
    Calcula goto(I, X) para un conjunto de elementos y un símbolo.
    
    Mueve el punto sobre X en todos los ítems donde toca X, 
    junta esos ítems en J, y luego closure(J).
    
    Args:
        items: Conjunto de elementos LR(1)
        symbol: Símbolo para mover el punto
        productions: Lista de producciones
        first_table: Tabla FIRST calculada
    
    Returns:
        set: goto(I, X)
    """
    goto_items = set()
    
    # Mover el punto sobre X en todos los ítems donde toca X
    for item in items:
        if item.get_symbol_after_dot() == symbol:
            new_item = LR1Item(item.production, item.dot_position + 1, item.lookahead)
            goto_items.add(new_item)
    
    # Calcular closure del conjunto resultante
    if goto_items:
        return calcular_closure_lr1(goto_items, productions, first_table)
    else:
        return set()


def construir_conjuntos_lr1_correcto(productions, terminals, nonterminals, first_table):
    """
    Construye la colección canónica de conjuntos LR(1) siguiendo el algoritmo correcto.
    
    Args:
        productions: Lista de producciones
        terminals: Lista de terminales
        nonterminals: Lista de no terminales
        first_table: Tabla FIRST calculada
    
    Returns:
        tuple: (conjuntos_lr1, transiciones)
    """
    # Encontrar el símbolo inicial real (no S')
    start_symbol = None
    for production in productions:
        left = production.split(' -> ')[0].strip()
        if left != "S'":
            start_symbol = left
            break
    
    if not start_symbol:
        start_symbol = productions[0].split(' -> ')[0].strip()
    
    # Filtrar producciones para evitar S' -> S' (que no existe)
    filtered_productions = []
    for production in productions:
        left, right = production.split(' -> ')
        if not (left.strip() == "S'" and right.strip() == "S'"):
            filtered_productions.append(production)
    
    # Agregar producción inicial aumentada solo si no existe
    augmented_productions = filtered_productions.copy()
    if not any(p.startswith("S' ->") for p in filtered_productions):
        augmented_productions = [f"S' -> {start_symbol}"] + filtered_productions
    
    # Estado inicial I0 = closure({ [S' → • S, $] })
    initial_item = LR1Item(f"S' -> {start_symbol}", 0, '$')
    initial_set = calcular_closure_lr1({initial_item}, augmented_productions, first_table)
    
    # Construir todos los conjuntos
    conjuntos = [initial_set]
    transiciones = {}
    estados_por_conjunto = {frozenset(initial_set): 0}
    
    i = 0
    while i < len(conjuntos):
        current_set = conjuntos[i]
        
        # Calcular transiciones desde este estado
        symbols_after_dot = set()
        for item in current_set:
            symbol = item.get_symbol_after_dot()
            if symbol:
                symbols_after_dot.add(symbol)
        
        for symbol in symbols_after_dot:
            # Calcular goto(I, symbol)
            goto_set = calcular_goto_lr1(current_set, symbol, augmented_productions, first_table)
            
            if goto_set:
                # Verificar si ya existe este conjunto
                goto_frozen = frozenset(goto_set)
                if goto_frozen in estados_por_conjunto:
                    estado_destino = estados_por_conjunto[goto_frozen]
                else:
                    estado_destino = len(conjuntos)
                    conjuntos.append(goto_set)
                    estados_por_conjunto[goto_frozen] = estado_destino
                
                transiciones[(i, symbol)] = estado_destino
        
        i += 1
    
    return conjuntos, transiciones


def verificar_y_corregir_lookaheads(conjuntos, follow_table, productions):
    """
    Verifica y corrige los lookaheads de los ítems completos según las reglas LR(1).
    Función genérica que funciona para cualquier gramática.
    
    REGLA FUNDAMENTAL LR(1):
    Un ítem completo A → α •, a solo puede reducir con lookaheads que pertenezcan a FOLLOW(A).
    
    Args:
        conjuntos: Lista de conjuntos de elementos LR(1)
        follow_table: Tabla FOLLOW calculada
        productions: Lista de producciones
    
    Returns:
        tuple: (conjuntos_corregidos, correcciones_aplicadas)
    """
    correcciones = []
    conjuntos_corregidos = []
    
    for state_idx, conjunto in enumerate(conjuntos):
        conjunto_corregido = set()
        
        # Agrupar ítems por producción y posición del punto
        items_por_produccion = {}
        
        for item in conjunto:
            if item.is_reduce_item():
                # Es un ítem completo A -> α •, a
                left_symbol = item.production.split(' -> ')[0].strip()
                key = (item.production, item.dot_position)
                
                if key not in items_por_produccion:
                    items_por_produccion[key] = {
                        'left_symbol': left_symbol,
                        'lookaheads': set(),
                        'items': []
                    }
                
                items_por_produccion[key]['lookaheads'].add(item.lookahead)
                items_por_produccion[key]['items'].append(item)
            else:
                # No es ítem completo, mantener tal como está
                conjunto_corregido.add(item)
        
        # Procesar cada grupo de ítems completos
        for key, data in items_por_produccion.items():
            production, dot_pos = key
            left_symbol = data['left_symbol']
            current_lookaheads = data['lookaheads']
            
            # Obtener FOLLOW(A)
            follow_a = set(follow_table.get(left_symbol, []))
            
            # Separar lookaheads válidos e inválidos
            valid_lookaheads = current_lookaheads.intersection(follow_a)
            invalid_lookaheads = current_lookaheads - follow_a
            
            # REGLA FUNDAMENTAL LR(1): 
            # Un ítem completo A → α •, a solo puede reducir con lookaheads que pertenezcan a FOLLOW(A)
            
            # CORRECCIÓN INTELIGENTE:
            # 1. Eliminar lookaheads que NO están en FOLLOW(A) (errores obvios)
            # 2. Agregar lookaheads faltantes que SÍ están en FOLLOW(A) (completar contexto)
            
            final_lookaheads = set()
            
            # Paso 1: Conservar solo lookaheads válidos
            final_lookaheads = valid_lookaheads
            
            # Paso 2: Agregar lookaheads faltantes según contexto LR(1)
            # Esto corrige casos como T -> F • que debería tener ), $ además de +
            for lookahead in follow_a:
                if lookahead not in final_lookaheads:
                    # Solo agregar si es un lookahead válido para este símbolo
                    final_lookaheads.add(lookahead)
            
            # Crear ítems corregidos
            for lookahead in final_lookaheads:
                corrected_item = LR1Item(production, dot_pos, lookahead)
                conjunto_corregido.add(corrected_item)
            
            # Registrar correcciones si hubo cambios
            if invalid_lookaheads or final_lookaheads != current_lookaheads:
                before_items = [str(item) for item in data['items']]
                after_items = [str(LR1Item(production, dot_pos, l)) for l in final_lookaheads]
                
                if invalid_lookaheads and len(final_lookaheads) > len(valid_lookaheads):
                    reason = f"Corrección completa: eliminar {sorted(list(invalid_lookaheads))} (no están en FOLLOW({left_symbol}) = {sorted(list(follow_a))}) y agregar lookaheads faltantes"
                elif invalid_lookaheads:
                    reason = f"Eliminar lookaheads inválidos {sorted(list(invalid_lookaheads))} (no pertenecen a FOLLOW({left_symbol}) = {sorted(list(follow_a))})"
                elif len(final_lookaheads) > len(current_lookaheads):
                    reason = f"Agregar lookaheads faltantes para FOLLOW({left_symbol}) = {sorted(list(follow_a))}"
                else:
                    reason = f"Ajustar lookaheads según FOLLOW({left_symbol}) = {sorted(list(follow_a))}"
                
                correcciones.append({
                    "state": state_idx,
                    "before": before_items,
                    "after": after_items,
                    "reason": reason
                })
        
        conjuntos_corregidos.append(conjunto_corregido)
    
    return conjuntos_corregidos, correcciones


def verificar_construccion_lr1(conjuntos, follow_table):
    """
    Verifica que la construcción LR(1) sea correcta siguiendo las reglas de oro.
    
    Args:
        conjuntos: Lista de conjuntos de elementos LR(1)
        follow_table: Tabla FOLLOW calculada
    
    Returns:
        dict: Resultado de la verificación
    """
    verificaciones = []
    errores_encontrados = 0
    
    for state_idx, conjunto in enumerate(conjuntos):
        estado_verificacion = {
            "state": state_idx,
            "items_completos": [],
            "errores": [],
            "aceptacion": False
        }
        
        for item in conjunto:
            if item.is_reduce_item():
                left_symbol = item.production.split(' -> ')[0].strip()
                lookahead = item.lookahead
                follow_a = set(follow_table.get(left_symbol, []))
                
                item_info = {
                    "item": str(item),
                    "left_symbol": left_symbol,
                    "lookahead": lookahead,
                    "follow": list(follow_a),
                    "valido": lookahead in follow_a
                }
                
                estado_verificacion["items_completos"].append(item_info)
                
                # Verificar reglas de oro
                if not item_info["valido"]:
                    estado_verificacion["errores"].append(
                        f"Lookahead '{lookahead}' no está en FOLLOW({left_symbol}) = {list(follow_a)}"
                    )
                    errores_encontrados += 1
                
                # Verificar estado de aceptación
                if left_symbol == "S'" and lookahead == "$":
                    estado_verificacion["aceptacion"] = True
        
        verificaciones.append(estado_verificacion)
    
    return {
        "verificaciones": verificaciones,
        "total_errores": errores_encontrados,
        "estados_aceptacion": [v["state"] for v in verificaciones if v["aceptacion"]],
        "correcto": errores_encontrados == 0
    }


def generar_closure_table_detallada(conjuntos, productions):
    """
    Genera una tabla de cierre LR(1) detallada con información adicional.
    
    Args:
        conjuntos: Lista de conjuntos de elementos LR(1)
        productions: Lista de producciones originales
    
    Returns:
        dict: Tabla de cierre detallada
    """
    closure_data = []
    
    for i, conjunto in enumerate(conjuntos):
        # Separar elementos por tipo
        kernel_items = []
        closure_items = []
        
        for item in conjunto:
            item_str = str(item)
            
            # Determinar si es elemento kernel o de cierre
            if item.dot_position == 0 and not item.production.startswith("S' ->"):
                # Es elemento de cierre (no kernel)
                closure_items.append({
                    "item": item_str,
                    "production": item.production,
                    "dot_position": item.dot_position,
                    "lookahead": item.lookahead,
                    "type": "closure"
                })
            else:
                # Es elemento kernel
                kernel_items.append({
                    "item": item_str,
                    "production": item.production,
                    "dot_position": item.dot_position,
                    "lookahead": item.lookahead,
                    "type": "kernel"
                })
        
        # Calcular transiciones desde este estado
        transitions = {}
        symbols_after_dot = set()
        
        for item in conjunto:
            symbol = item.get_symbol_after_dot()
            if symbol:
                symbols_after_dot.add(symbol)
        
        for symbol in symbols_after_dot:
            # Contar cuántos elementos tienen este símbolo después del punto
            count = sum(1 for item in conjunto if item.get_symbol_after_dot() == symbol)
            transitions[symbol] = {
                "symbol": symbol,
                "item_count": count,
                "items": [str(item) for item in conjunto if item.get_symbol_after_dot() == symbol]
            }
        
        closure_data.append({
            "state": i,
            "kernel_items": kernel_items,
            "closure_items": closure_items,
            "total_items": len(conjunto),
            "transitions": transitions,
            "all_items": [str(item) for item in conjunto]
        })
    
    return closure_data


def generar_json_closure_table(closure_data, grammar_info, terminals, nonterminals):
    """
    Genera un JSON estructurado para mostrar la tabla de cierre LR(1).
    
    Args:
        closure_data: Datos de la tabla de cierre
        grammar_info: Información de la gramática
        terminals: Lista de terminales
        nonterminals: Lista de no terminales
    
    Returns:
        dict: JSON estructurado para la tabla de cierre
    """
    # Filtrar epsilon de terminales
    terminals_filtered = [t for t in terminals if t != 'ε']
    
    return {
        "success": True,
        "operation": "lr1_closure_table",
        "grammar": {
            "productions": grammar_info["productions"],
            "start_symbol": grammar_info["start_symbol"]
        },
        "closure_table": closure_data,
        "terminals": terminals_filtered,
        "nonterminals": nonterminals,
        "summary": {
            "total_states": len(closure_data),
            "total_terminals": len(terminals_filtered),
            "total_nonterminals": len(nonterminals),
            "total_items": sum(state["total_items"] for state in closure_data)
        }
    }


def lambda_handler(event, context):
    try:
        # Parsear el body si viene como string
        if isinstance(event.get('body'), str):
            body = json.loads(event['body'])
        else:
            body = event
        
        # Verificar que sea operación de LR1 closure table
        if body.get('operation') != 'lr1_closure_table':
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Operation must be lr1_closure_table'})
            }
        
        # Verificar que tenga gramática y first_table
        if 'grammar' not in body:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'grammar is required'})
            }
        
        if 'first_table' not in body:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'first_table is required for LR(1) closure'})
            }
        
        # Expandir producciones con | (pipe) en múltiples producciones
        expanded_productions = expandir_producciones_con_pipe(body['grammar']['productions'])
        print(f"Producciones expandidas: {expanded_productions}")
        
        # Extraer terminales y no terminales
        terminals, nonterminals = extraer_symbols_from_grammar(expanded_productions)
        print(f"Terminales: {terminals}")
        print(f"No terminales: {nonterminals}")
        
        # Usar la tabla FIRST proporcionada
        first_table = body['first_table']
        print(f"Tabla FIRST recibida: {first_table}")
        
        # Calcular FOLLOW automáticamente usando la tabla FIRST proporcionada
        follow_table = calcular_follow_table(expanded_productions, terminals, nonterminals, first_table)
        print(f"Tabla FOLLOW calculada: {follow_table}")
        
        # Construir conjuntos LR(1) usando el algoritmo correcto
        conjuntos, transiciones = construir_conjuntos_lr1_correcto(
            expanded_productions,
            terminals,
            nonterminals,
            first_table
        )
        print(f"Número de estados: {len(conjuntos)}")
        
        # Verificar y corregir lookaheads automáticamente
        conjuntos_corregidos, correcciones = verificar_y_corregir_lookaheads(
            conjuntos, follow_table, expanded_productions
        )
        print(f"Correcciones aplicadas: {len(correcciones)}")
        
        # Verificar construcción LR(1) según reglas de oro
        verificacion = verificar_construccion_lr1(conjuntos, follow_table)
        print(f"Verificación LR(1): {'✓ Correcto' if verificacion['correcto'] else '✗ Errores encontrados'}")
        
        # Generar tabla de cierre detallada (mantener conjuntos originales para compatibilidad)
        closure_data = generar_closure_table_detallada(conjuntos, body['grammar']['productions'])
        
        # Generar JSON estructurado para la tabla de cierre (manteniendo estructura original)
        result = generar_json_closure_table(closure_data, body['grammar'], terminals, nonterminals)
        
        # Agregar información adicional de correcciones (sin cambiar estructura principal)
        result["corrections_applied"] = correcciones
        result["follow_sets"] = follow_table
        result["first_sets"] = {symbol: first_table[symbol] for symbol in first_table.keys() 
                              if symbol.isupper() or (symbol.startswith(symbol[0].upper()) and "'" in symbol)}
        result["verification"] = verificacion
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps(result, indent=2)
        }
        
    except Exception as e:
        logger.error(f"Error en lambda_handler: {str(e)}")
        import traceback
        traceback.print_exc()
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': str(e), 'success': False})
        }





