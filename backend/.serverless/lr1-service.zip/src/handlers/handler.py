import json
import os
import logging
from datetime import datetime
from typing import Dict, Any
from src.utils.funciones_auxiales import (
    extraer_symbols_from_grammar,
    calcular_first_table,
    generar_json_first_table
)
# Configurar logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event, context):
    try:
        # Parsear el body si viene como string
        if isinstance(event.get('body'), str):
            body = json.loads(event['body'])
        else:
            body = event
        
        # Verificar que sea operación de FIRST table
        if body.get('operation') != 'first_table':
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Operation must be first_table'})
            }
        
        # Verificar que solo tenga gramática (no debe tener first_table)
        if 'first_table' in body:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'FIRST handler only needs grammar, not first_table'})
            }
        
        # Extraer terminales y no terminales
        terminals, nonterminals = extraer_symbols_from_grammar(body['grammar']['productions'])
        print(f"Terminales: {terminals}")
        print(f"No terminales: {nonterminals}")
        
        # Calcular tabla FIRST
        first_table = calcular_first_table(
            body['grammar']['productions'], 
            terminals, 
            nonterminals
        )
        print(f"Tabla FIRST: {first_table}")
        
        # Generar JSON estructurado para la tabla
        result = generar_json_first_table(first_table, body['grammar'])
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps(result, indent=2)
        }
        
    except Exception as e:
        logger.error(f"Error en lambda_handler: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': str(e), 'success': False})
        }
test_events = [
    # Caso 1: Gramática simple con terminales directos
    {
        'body': json.dumps({
            "grammar": {
                "productions": [
                    "S -> a",
                    "S -> b"
                ],
                "start_symbol": "S"
            },
            "operation": "first_table"
        })
    },
    
    # Caso 2: Gramática con epsilon (producciones vacías)
    {
        'body': json.dumps({
            "grammar": {
                "productions": [
                    "S -> A B",
                    "A -> a",
                    "A -> ε",
                    "B -> b",
                    "B -> ε"
                ],
                "start_symbol": "S"
            },
            "operation": "first_table"
        })
    },
    
    # Caso 3: Gramática con múltiples niveles de no terminales
    {
        'body': json.dumps({
            "grammar": {
                "productions": [
                    "S -> A B C",
                    "A -> a",
                    "B -> b",
                    "C -> c"
                ],
                "start_symbol": "S"
            },
            "operation": "first_table"
        })
    },
    
    # Caso 4: Gramática con recursión a izquierda
    {
        'body': json.dumps({
            "grammar": {
                "productions": [
                    "E -> E + T",
                    "E -> T",
                    "T -> T * F",
                    "T -> F",
                    "F -> ( E )",
                    "F -> id"
                ],
                "start_symbol": "E"
            },
            "operation": "first_table"
        })
    },
    
    # Caso 5: Gramática con producciones alternativas complejas
    {
        'body': json.dumps({
            "grammar": {
                "productions": [
                    "S -> if E then S else S",
                    "S -> while E do S",
                    "S -> id = E",
                    "E -> id",
                    "E -> num",
                    "E -> E + E"
                ],
                "start_symbol": "S"
            },
            "operation": "first_table"
        })
    },
    
    # Caso 6: No terminal con múltiples producciones
    {
        'body': json.dumps({
            "grammar": {
                "productions": [
                    "S -> A",
                    "A -> a",
                    "A -> b",
                    "A -> c",
                    "A -> d",
                    "A -> e"
                ],
                "start_symbol": "S"
            },
            "operation": "first_table"
        })
    },
    
    # Caso 7: Cadena de no terminales
    {
        'body': json.dumps({
            "grammar": {
                "productions": [
                    "S -> A",
                    "A -> B",
                    "B -> C",
                    "C -> d"
                ],
                "start_symbol": "S"
            },
            "operation": "first_table"
        })
    },
    
    # Caso 8: Mezcla de terminales y no terminales
    {
        'body': json.dumps({
            "grammar": {
                "productions": [
                    "S -> a A b",
                    "S -> B c",
                    "A -> d",
                    "A -> ε",
                    "B -> e",
                    "B -> ε"
                ],
                "start_symbol": "S"
            },
            "operation": "first_table"
        })
    },
    
    # Caso 9: Producción solo con no terminal
    {
        'body': json.dumps({
            "grammar": {
                "productions": [
                    "S -> A",
                    "A -> B",
                    "B -> a"
                ],
                "start_symbol": "S"
            },
            "operation": "first_table"
        })
    },
    
    # Caso 10: Gramática de expresiones
    {
        'body': json.dumps({
            "grammar": {
                "productions": [
                    "E -> T E'",
                    "E' -> + T E'",
                    "E' -> ε",
                    "T -> F T'",
                    "T' -> * F T'",
                    "T' -> ε",
                    "F -> ( E )",
                    "F -> id"
                ],
                "start_symbol": "E"
            },
            "operation": "first_table"
        })
    },
    
    # Caso 11: Un solo terminal
    {
        'body': json.dumps({
            "grammar": {
                "productions": [
                    "S -> x"
                ],
                "start_symbol": "S"
            },
            "operation": "first_table"
        })
    },
    
    # Caso 12: Múltiples epsilons en secuencia
    {
        'body': json.dumps({
            "grammar": {
                "productions": [
                    "S -> A B C D",
                    "A -> a",
                    "A -> ε",
                    "B -> b",
                    "B -> ε",
                    "C -> c",
                    "C -> ε",
                    "D -> d"
                ],
                "start_symbol": "S"
            },
            "operation": "first_table"
        })
    }
]

# Ejecutar pruebas y guardar resultados
if __name__ == '__main__':
    all_results = []
    
    for i, event in enumerate(test_events, 1):
        print(f"\n{'='*60}")
        print(f"PRUEBA {i}")
        print(f"{'='*60}")
        
        result = lambda_handler(event, None)
        print(f"Status Code: {result['statusCode']}")
        
        # Parsear el evento original
        event_data = json.loads(event['body'])
        
        # Crear resultado completo
        test_result = {
            "test_number": i,
            "test_name": f"Prueba {i}",
            "grammar": event_data["grammar"],
            "operation": event_data["operation"],
            "status_code": result['statusCode'],
            "success": result['statusCode'] == 200,
            "timestamp": datetime.utcnow().isoformat() + 'Z'
        }
        
        if result['statusCode'] == 200:
            body = json.loads(result['body'])
            test_result["result"] = body
            print(" Éxito")
            print(json.dumps(body, indent=2))
        else:
            error_body = json.loads(result['body'])
            test_result["error"] = error_body
            print(f"Error: {result['body']}")
        
        all_results.append(test_result)
    
    # Guardar todos los resultados en un archivo JSON
    output_file = "test_results.json"
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    
    print(f"\n{'='*60}")
    print(f"RESUMEN FINAL")
    print(f"{'='*60}")
    
    successful_tests = sum(1 for r in all_results if r['success'])
    total_tests = len(all_results)
    
    print(f"Tests exitosos: {successful_tests}/{total_tests}")
    print(f"Tasa de éxito: {(successful_tests/total_tests)*100:.1f}%")
    print(f"Resultados guardados en: {output_file}")